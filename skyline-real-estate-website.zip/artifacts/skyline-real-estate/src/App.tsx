import { type FormEvent, type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ArrowDown, ArrowRight, ArrowUp, ArrowUpRight, Building2, Check, CircleCheck, Compass, FileCheck2, Mail, MapPin, Menu, MessageCircle, MoveRight, Quote, Search, ShieldCheck, Star, X } from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter, useLocation } from 'wouter';

const queryClient = new QueryClient();

// Business-specific configuration: edit these values when contact details change.
const BUSINESS_NAME = 'Skyline Real Estate Consultancy Khatushyamji';
const BUSINESS_PHONE = '';
const BUSINESS_ADDRESS = 'Sita Kund, Kolawat Petrol Pump, Aloda Road, Khatoo, Rajasthan 332602, India';
const MAPS_URL = 'https://maps.app.goo.gl/g5w1NDPS5KbLsqrU8';
const BUSINESS_RATING = '5.0';

type Category = 'All' | 'Residential' | 'Commercial' | 'Land';
type Property = { id: number; category: Exclude<Category, 'All'>; title: string; eyebrow: string; image: string; description: string; highlights: string[] };

const properties: Property[] = [
  { id: 1, category: 'Residential', title: 'A quieter address near Khatoo', eyebrow: 'Sample residence / enquiry based', image: 'https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=1400', description: 'A sample residential brief for buyers seeking a considered home base around Khatushyamji. Exact availability, specifications and terms are shared on enquiry.', highlights: ['Residential use', 'Khatoo vicinity', 'Details on enquiry'] },
  { id: 2, category: 'Commercial', title: 'A visible edge for local business', eyebrow: 'Sample commercial / enquiry based', image: 'https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=1400', description: 'A sample commercial opportunity profile built around access and visibility. Use this as a conversation starter; current inventory and commercial terms require confirmation.', highlights: ['Commercial use', 'Road-facing potential', 'Terms on enquiry'] },
  { id: 3, category: 'Land', title: 'Open ground, clear next step', eyebrow: 'Sample land / enquiry based', image: 'https://images.pexels.com/photos/2132227/pexels-photo-2132227.jpeg?auto=compress&cs=tinysrgb&w=1400', description: 'A sample land brief for those assessing a longer-term move around Khatushyamji. Plot dimensions, title information and suitability are discussed case by case.', highlights: ['Land opportunity', 'Suitability to assess', 'Information on enquiry'] },
  { id: 4, category: 'Residential', title: 'Room to shape your own rhythm', eyebrow: 'Sample residence / enquiry based', image: 'https://images.pexels.com/photos/7031608/pexels-photo-7031608.jpeg?auto=compress&cs=tinysrgb&w=1400', description: 'A sample home search direction for people who value practical comfort and a sense of place. No property details are implied until the brief is verified.', highlights: ['Residential use', 'Lifestyle-led search', 'Details on enquiry'] },
];

const navItems = [
  ['Home', 'home'], ['Properties', 'properties'], ['Services', 'services'],
  ['About', 'about'], ['Why us', 'why-us'], ['Contact', 'contact'],
] as const;

function scrollToId(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function RemoteImage({ src, alt, className = '', eager = false }: { src: string; alt: string; className?: string; eager?: boolean }) {
  const [failed, setFailed] = useState(false);
  return failed ? (
    <div className={`flex h-full w-full items-center justify-center bg-[#242633] text-[#d7b77a] ${className}`} aria-label={alt}>
      <Building2 size={42} strokeWidth={1} />
    </div>
  ) : (
    <img src={src} alt={alt} className={`h-full w-full object-cover ${className}`} loading={eager ? 'eager' : 'lazy'} onError={() => setFailed(true)} />
  );
}

function SectionIntro({ number, kicker, title, children, light = false }: { number: string; kicker: string; title: ReactNode; children?: ReactNode; light?: boolean }) {
  return (
    <div className={`grid gap-6 lg:grid-cols-[150px_1fr_1.05fr] lg:items-end ${light ? 'text-[#f5f0e7]' : ''}`}>
      <div className="flex items-center gap-4 lg:block">
        <span className={`font-mono text-[11px] tracking-[.22em] ${light ? 'text-[#d7b77a]' : 'text-[#a37c3d]'}`}>{number}</span>
        <div className={`mt-0 h-px w-16 lg:mt-5 ${light ? 'bg-[#d7b77a]/70' : 'gold-rule'}`} />
      </div>
      <div>
        <p className={`mb-4 font-mono text-[11px] uppercase tracking-[.25em] ${light ? 'text-[#d7b77a]' : 'text-[#a37c3d]'}`}>{kicker}</p>
        <h2 className="max-w-3xl font-serif text-5xl leading-[.94] tracking-[-.03em] sm:text-6xl lg:text-7xl">{title}</h2>
      </div>
      {children && <p className={`max-w-md text-base leading-7 lg:pb-1 ${light ? 'text-[#d2cfc6]' : 'text-[#6f6c66]'}`}>{children}</p>}
    </div>
  );
}

function Home() {
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [progress, setProgress] = useState(0);
  const [activeSection, setActiveSection] = useState('home');
  const [category, setCategory] = useState<Category>('All');
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [form, setForm] = useState({ name: '', mobile: '', requirement: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = window.setTimeout(() => setLoading(false), 900);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const onScroll = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(max ? (window.scrollY / max) * 100 : 0);
      if (heroRef.current) heroRef.current.style.setProperty('--parallax', `${Math.min(window.scrollY * .08, 32)}px`);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const sections = navItems.map(([, id]) => document.getElementById(id)).filter(Boolean) as HTMLElement[];
    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (visible) setActiveSection(visible.target.id);
    }, { rootMargin: '-28% 0px -58% 0px', threshold: [0.1, .3, .6] });
    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, [loading]);

  useEffect(() => {
    const revealObserver = new IntersectionObserver((entries) => entries.forEach((entry) => entry.isIntersecting && entry.target.classList.add('is-visible')), { threshold: .12 });
    document.querySelectorAll('.reveal').forEach((element) => revealObserver.observe(element));
    return () => revealObserver.disconnect();
  }, [loading]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => event.key === 'Escape' && setSelectedProperty(null);
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);

  const filteredProperties = useMemo(() => category === 'All' ? properties : properties.filter((property) => property.category === category), [category]);

  const handleEnquiry = (event: FormEvent) => {
    event.preventDefault();
    const next: Record<string, string> = {};
    if (form.name.trim().length < 2) next.name = 'Please enter your name.';
    if (!/^[6-9]\d{9}$/.test(form.mobile.replace(/\D/g, ''))) next.mobile = 'Please enter a valid 10-digit mobile number.';
    if (form.requirement.trim().length < 12) next.requirement = 'Tell us a little more about what you are looking for.';
    setErrors(next);
    if (Object.keys(next).length === 0) {
      setSubmitted(true);
      setForm({ name: '', mobile: '', requirement: '' });
    }
  };

  const goToContact = () => { setMenuOpen(false); scrollToId('contact'); };

  if (loading) {
    return <div className="preload-screen flex min-h-[100dvh] items-center justify-center bg-[#20222d] text-[#f5f0e7]" data-testid="status-preloader"><div className="text-center"><div className="mx-auto mb-7 flex h-14 w-14 items-center justify-center border border-[#d7b77a]"><span className="font-serif text-2xl text-[#d7b77a]">S</span></div><p className="font-mono text-[10px] uppercase tracking-[.35em] text-[#bcb8ae]">Skyline / Khatushyamji</p></div></div>;
  }

  return (
    <div className="site-shell overflow-hidden bg-[#f3eee5] text-[#242633]" data-testid="page-skyline-home">
      <div className="fixed left-0 top-0 z-[60] h-[3px] bg-[#c19a58] transition-[width] duration-150" style={{ width: `${progress}%` }} aria-hidden="true" />
      <header className="absolute left-0 top-0 z-40 w-full px-5 py-5 text-[#f8f3eb] sm:px-8 lg:px-12" data-testid="header-site">
        <div className="mx-auto flex max-w-[1440px] items-center justify-between">
          <button className="group flex items-center gap-3 text-left" onClick={() => scrollToId('home')} data-testid="button-logo">
            <span className="flex h-10 w-10 items-center justify-center border border-[#d7b77a] font-serif text-xl text-[#d7b77a] transition-colors group-hover:bg-[#d7b77a] group-hover:text-[#242633]">S</span>
            <span><span className="block font-mono text-[9px] uppercase tracking-[.22em] text-[#d7b77a]">Skyline</span><span className="block text-sm font-medium tracking-wide">Real Estate Consultancy</span></span>
          </button>
          <nav className="hidden items-center gap-7 lg:flex" aria-label="Primary navigation">
            {navItems.map(([label, id]) => <button key={id} onClick={() => scrollToId(id)} className={`relative py-2 text-[12px] transition-colors ${activeSection === id ? 'text-[#d7b77a]' : 'text-[#e4dfd5]/80 hover:text-[#fff]'}`} data-testid={`link-nav-${id}`}>{label}{activeSection === id && <span className="absolute -bottom-1 left-0 h-px w-full bg-[#d7b77a]" />}</button>)}
          </nav>
          <button className="flex items-center gap-2 border border-[#e4dfd5]/35 px-4 py-2.5 text-[11px] uppercase tracking-[.15em] transition-colors hover:border-[#d7b77a] hover:text-[#d7b77a] lg:hidden" onClick={() => setMenuOpen(!menuOpen)} data-testid="button-mobile-menu" aria-label="Toggle menu">{menuOpen ? <X size={16} /> : <Menu size={16} />} Menu</button>
          <button className="hidden items-center gap-2 border border-[#d7b77a] px-5 py-3 text-[11px] uppercase tracking-[.15em] text-[#f8f3eb] transition-colors hover:bg-[#d7b77a] hover:text-[#242633] lg:flex" onClick={goToContact} data-testid="button-header-enquiry">Start an enquiry <ArrowUpRight size={14} /></button>
        </div>
        {menuOpen && <div className="mx-auto mt-4 max-w-[1440px] border border-[#e4dfd5]/20 bg-[#20222d]/95 p-5 backdrop-blur-md lg:hidden">{navItems.map(([label, id]) => <button key={id} className="block w-full border-b border-[#e4dfd5]/10 py-3 text-left text-sm text-[#f8f3eb]" onClick={() => { setMenuOpen(false); scrollToId(id); }} data-testid={`link-mobile-${id}`}>{label}</button>)}<button onClick={goToContact} className="mt-4 flex items-center gap-2 text-sm text-[#d7b77a]" data-testid="button-mobile-enquiry">Make an enquiry <ArrowUpRight size={14} /></button></div>}
      </header>

      <main>
        <section id="home" className="relative min-h-[720px] bg-[#20222d] text-[#f8f3eb] sm:min-h-[800px]" ref={heroRef} data-testid="section-home">
          <div className="absolute inset-0 overflow-hidden"><RemoteImage src="https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=2000" alt="Architectural property exterior" eager className="hero-image parallax-image opacity-55" /><div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(32,34,45,.98)_4%,rgba(32,34,45,.78)_45%,rgba(32,34,45,.25)_100%)]" /><div className="absolute inset-0 bg-[linear-gradient(0deg,rgba(32,34,45,.72),transparent_42%)]" /></div>
          <div className="relative mx-auto flex min-h-[720px] max-w-[1440px] flex-col justify-end px-5 pb-16 pt-36 sm:min-h-[800px] sm:px-8 sm:pb-24 lg:px-12">
            <div className="max-w-4xl reveal is-visible">
              <p className="mb-6 flex items-center gap-3 font-mono text-[10px] uppercase tracking-[.32em] text-[#d7b77a]"><span className="h-px w-9 bg-[#d7b77a]" /> A grounded view of property</p>
              <h1 className="max-w-4xl font-serif text-[4.5rem] leading-[.86] tracking-[-.04em] sm:text-[7.2rem] lg:text-[9.2rem]">Make room<br /><em className="text-[#d7b77a]">for what matters.</em></h1>
              <div className="mt-9 flex flex-col gap-7 sm:flex-row sm:items-end sm:justify-between">
                <p className="max-w-sm text-base leading-7 text-[#d2cfc6]">A local property partner for confident decisions around Khatushyamji — with clarity before commitment.</p>
                <button onClick={() => scrollToId('properties')} className="group flex w-fit items-center gap-4 border-b border-[#d7b77a] pb-3 text-[11px] uppercase tracking-[.2em] text-[#f8f3eb]" data-testid="button-explore-properties">Explore sample properties <ArrowDown size={15} className="transition-transform group-hover:translate-y-1" /></button>
              </div>
            </div>
            <div className="mt-20 flex items-end justify-between border-t border-[#f8f3eb]/20 pt-5 text-[10px] uppercase tracking-[.22em] text-[#bcb8ae]"><span>Khatoo · Rajasthan</span><span className="hidden sm:block">Real Estate Consultant</span><span className="flex items-center gap-2"><Star size={12} className="fill-[#d7b77a] text-[#d7b77a]" /> {BUSINESS_RATING} Google rating</span></div>
          </div>
        </section>

        <section className="border-b border-[#d8d0c3] bg-[#ece5d9]" data-testid="section-trust-strip"><div className="mx-auto grid max-w-[1440px] divide-y divide-[#d8d0c3] px-5 sm:grid-cols-3 sm:divide-x sm:divide-y-0 sm:px-8 lg:px-12"><div className="flex items-center gap-4 py-5 sm:px-7 sm:py-7 sm:first:pl-0"><Compass size={20} className="text-[#a37c3d]" /><span className="text-sm">Local perspective, not portal noise</span></div><div className="flex items-center gap-4 py-5 sm:px-7 sm:py-7"><ShieldCheck size={20} className="text-[#a37c3d]" /><span className="text-sm">A clearer way to assess your next move</span></div><div className="flex items-center gap-4 py-5 sm:px-7 sm:py-7 sm:last:pr-0"><MapPin size={20} className="text-[#a37c3d]" /><span className="text-sm">Rooted in Khatushyamji, Rajasthan</span></div></div></section>

        <section id="properties" className="mx-auto max-w-[1440px] scroll-mt-20 px-5 py-24 sm:px-8 sm:py-32 lg:px-12" data-testid="section-properties">
          <SectionIntro number="01 / 05" kicker="The sample browser" title={<>A shortlist, not a <em className="text-[#a37c3d]">search result.</em></>}><span>Browse illustrative property directions to start a useful conversation. Every card is sample/demo content; current availability and terms are shared on enquiry.</span></SectionIntro>
          <div className="mt-14 flex flex-col justify-between gap-6 border-y border-[#d8d0c3] py-4 sm:flex-row sm:items-center"><div className="flex flex-wrap gap-2" role="tablist" aria-label="Property categories">{(['All', 'Residential', 'Commercial', 'Land'] as Category[]).map((item) => <button key={item} onClick={() => setCategory(item)} className={`px-4 py-2 text-[11px] uppercase tracking-[.16em] transition-colors ${category === item ? 'bg-[#242633] text-[#f8f3eb]' : 'text-[#6f6c66] hover:bg-[#e4ddd0]'}`} data-testid={`button-filter-${item.toLowerCase()}`}>{item}</button>)}</div><span className="font-mono text-[10px] uppercase tracking-[.18em] text-[#8a857b]">{filteredProperties.length} sample directions</span></div>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{filteredProperties.map((property, index) => <article key={property.id} className={`group reveal reveal-delay-${Math.min(index + 1, 3)} overflow-hidden border border-[#d8d0c3] bg-[#f7f2e9] transition-all duration-500 hover:-translate-y-1 hover:border-[#b18b4c] hover:shadow-[var(--shadow-card)]`} data-testid={`card-property-${property.id}`}><button onClick={() => setSelectedProperty(property)} className="block w-full text-left" data-testid={`button-open-property-${property.id}`}><div className="relative aspect-[1.13] overflow-hidden"><RemoteImage src={property.image} alt={property.title} className="transition-transform duration-700 group-hover:scale-105" /><span className="absolute left-3 top-3 bg-[#f7f2e9]/90 px-2.5 py-1 font-mono text-[9px] uppercase tracking-[.13em] text-[#735322]">Sample / demo</span><span className="absolute bottom-3 right-3 flex h-9 w-9 items-center justify-center bg-[#242633] text-[#f8f3eb] opacity-0 transition-opacity group-hover:opacity-100"><ArrowUpRight size={15} /></span></div><div className="p-5"><p className="font-mono text-[9px] uppercase tracking-[.16em] text-[#a37c3d]">{property.category}</p><h3 className="mt-3 font-serif text-2xl leading-none">{property.title}</h3><p className="mt-4 text-sm leading-6 text-[#77736a]">{property.eyebrow}</p><div className="mt-6 flex items-center justify-between border-t border-[#ded6ca] pt-4 text-[10px] uppercase tracking-[.12em] text-[#817c72]"><span>View direction</span><ArrowRight size={14} className="text-[#a37c3d] transition-transform group-hover:translate-x-1" /></div></div></button></article>)}</div>
          <div className="mt-12 flex flex-col items-start justify-between gap-5 border-l-2 border-[#c19a58] bg-[#ebe3d6] p-5 sm:flex-row sm:items-center sm:p-6"><p className="max-w-xl text-sm leading-6 text-[#5e5b55]"><strong className="font-medium text-[#242633]">Looking for something specific?</strong> Share your location, use and timeline. We will shape the next conversation around your requirement.</p><button onClick={goToContact} className="flex shrink-0 items-center gap-2 text-[11px] uppercase tracking-[.16em] text-[#7b5b2d]" data-testid="button-property-enquiry">Tell us your requirement <MoveRight size={16} /></button></div>
        </section>

        <section id="services" className="scroll-mt-20 bg-[#242633] px-5 py-24 text-[#f7f2e9] sm:px-8 sm:py-32 lg:px-12" data-testid="section-services"><div className="mx-auto max-w-[1440px]"><SectionIntro number="02 / 05" kicker="The work behind the decision" title={<>Good property advice is<br /><em className="text-[#d7b77a]">specific.</em></>} light><span>From first conversation to a more informed next step, our role is to make the local property journey easier to read.</span></SectionIntro><div className="mt-20 grid gap-px border border-[#f8f3eb]/15 bg-[#f8f3eb]/15 md:grid-cols-2 lg:grid-cols-4">{[{ icon: Search, n: '01', title: 'Requirement mapping', text: 'We begin with what you need, where you want to be and what a sensible next step looks like.' }, { icon: Building2, n: '02', title: 'Property direction', text: 'Explore sample directions across residential, commercial and land conversations around Khatoo.' }, { icon: FileCheck2, n: '03', title: 'Clarity before commitment', text: 'Ask the practical questions early. Details, documents and terms are discussed on enquiry.' }, { icon: CircleCheck, n: '04', title: 'A considered handoff', text: 'Move forward with a clearer brief and the right questions for the next stage.' }].map(({ icon: Icon, n, title, text }) => <div key={n} className="group bg-[#242633] p-7 transition-colors hover:bg-[#2d303e] sm:p-9"><Icon size={23} strokeWidth={1.25} className="text-[#d7b77a]" /><p className="mt-16 font-mono text-[10px] tracking-[.2em] text-[#8e8d8a]">{n}</p><h3 className="mt-3 font-serif text-3xl">{title}</h3><p className="mt-4 text-sm leading-6 text-[#bcb8ae]">{text}</p></div>)}</div></div></section>

        <section id="about" className="scroll-mt-20 bg-[#e9e1d4] px-5 py-24 sm:px-8 sm:py-32 lg:px-12" data-testid="section-about"><div className="mx-auto grid max-w-[1440px] gap-14 lg:grid-cols-[.8fr_1.2fr] lg:gap-24"><div className="reveal relative min-h-[480px] overflow-hidden bg-[#d4cab9]"><RemoteImage src="https://images.pexels.com/photos/280222/pexels-photo-280222.jpeg?auto=compress&cs=tinysrgb&w=1200" alt="Warmly lit property interior" className="parallax-image" /><div className="absolute bottom-0 left-0 bg-[#242633] p-5 text-[#f8f3eb]"><p className="font-mono text-[10px] uppercase tracking-[.2em] text-[#d7b77a]">Sita Kund · Aloda Road</p><p className="mt-2 max-w-[180px] font-serif text-xl leading-tight">Close to the place you are considering.</p></div></div><div className="flex flex-col justify-center"><SectionIntro number="03 / 05" kicker="About Skyline" title={<>Rooted here.<br /><em className="text-[#a37c3d]">Looking closely.</em></>}><span>Skyline Real Estate Consultancy Khatushyamji is a local real estate consultancy for people making property decisions around Khatushyamji. We keep the conversation grounded in place, practical detail and your actual requirement.</span></SectionIntro><div className="mt-12 grid gap-7 border-t border-[#cdc3b4] pt-7 sm:grid-cols-2"><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#a37c3d]">What we believe</p><p className="mt-3 text-sm leading-6 text-[#69655d]">The right property conversation starts before the property tour — with a clear understanding of what matters to you.</p></div><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#a37c3d]">Where we are</p><p className="mt-3 text-sm leading-6 text-[#69655d]">Sita Kund, Kolawat Petrol Pump, Aloda Road, Khatoo, Rajasthan 332602.</p></div></div></div></div></section>

        <section id="why-us" className="scroll-mt-20 mx-auto max-w-[1440px] px-5 py-24 sm:px-8 sm:py-32 lg:px-12" data-testid="section-why-us"><SectionIntro number="04 / 05" kicker="Why people begin here" title={<>A better first<br /><em className="text-[#a37c3d]">conversation.</em></>}><span>No inflated promises. Just a local point of view, a clear process and room to ask better questions about your next move.</span></SectionIntro><div className="mt-16 grid gap-10 lg:grid-cols-[1.2fr_.8fr]"><div className="relative border-t border-[#cfc5b6] pt-8"><Quote size={36} strokeWidth={1} className="absolute right-0 top-7 text-[#c19a58]" /><p className="max-w-2xl font-serif text-4xl leading-[1.05] sm:text-5xl">“Confidence comes from knowing what to ask, not from being rushed to decide.”</p><p className="mt-8 font-mono text-[10px] uppercase tracking-[.2em] text-[#8a857b]">The Skyline approach</p></div><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1">{['Local context over generic listings', 'Enquiry-based, transparent detail', 'A measured pace for meaningful decisions'].map((item, index) => <div key={item} className="flex items-start gap-5 border-b border-[#d8d0c3] pb-5"><span className="font-mono text-[11px] text-[#a37c3d]">0{index + 1}</span><p className="text-sm leading-6">{item}</p></div>)}</div></div></section>

        <section className="bg-[#dcd1c1] px-5 py-24 sm:px-8 sm:py-32 lg:px-12" data-testid="section-process"><div className="mx-auto max-w-[1440px]"><div className="grid gap-8 lg:grid-cols-[.65fr_1.35fr]"><div><p className="font-mono text-[11px] uppercase tracking-[.25em] text-[#a37c3d]">A simple way in</p><h2 className="mt-5 max-w-xs font-serif text-5xl leading-[.92]">Start with a question.</h2></div><div className="grid gap-8 border-t border-[#bfb2a0] pt-7 sm:grid-cols-2 lg:grid-cols-4">{[{ n: '01', title: 'Share', text: 'Tell us what you are exploring.' }, { n: '02', title: 'Narrow', text: 'Clarify use, location and priorities.' }, { n: '03', title: 'Review', text: 'Discuss relevant directions.' }, { n: '04', title: 'Decide', text: 'Take your next step informed.' }].map((step) => <div key={step.n}><span className="font-mono text-[11px] text-[#a37c3d]">{step.n}</span><h3 className="mt-10 font-serif text-2xl">{step.title}</h3><p className="mt-2 text-sm leading-6 text-[#69655d]">{step.text}</p></div>)}</div></div></div></section>

        <section id="contact" className="scroll-mt-20 bg-[#242633] px-5 py-24 text-[#f8f3eb] sm:px-8 sm:py-32 lg:px-12" data-testid="section-contact"><div className="mx-auto grid max-w-[1440px] gap-16 lg:grid-cols-[.86fr_1.14fr] lg:gap-28"><div><SectionIntro number="05 / 05" kicker="Make a clear start" title={<>Your next move<br /><em className="text-[#d7b77a]">starts here.</em></>} light><span>Tell us what you are considering. We will respond around your requirement — not a generic catalogue.</span></SectionIntro><div className="mt-14 space-y-5 border-t border-[#f8f3eb]/15 pt-6"><div className="flex gap-4"><MapPin size={18} className="mt-1 shrink-0 text-[#d7b77a]" /><p className="max-w-xs text-sm leading-6 text-[#c9c6be]">{BUSINESS_ADDRESS}</p></div><a href={MAPS_URL} target="_blank" rel="noreferrer" className="flex w-fit items-center gap-2 text-[11px] uppercase tracking-[.18em] text-[#d7b77a] hover:text-[#f8f3eb]" data-testid="link-google-maps">Open in Google Maps <ArrowUpRight size={14} /></a></div></div><div className="border border-[#f8f3eb]/15 bg-[#2b2d39] p-6 sm:p-9"><div className="mb-8 flex items-start justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[.22em] text-[#d7b77a]">Enquiry form</p><h3 className="mt-3 font-serif text-3xl">Let us understand the brief.</h3></div><MessageCircle size={25} strokeWidth={1} className="text-[#d7b77a]" /></div>{submitted ? <div className="flex min-h-[320px] flex-col items-center justify-center border border-[#d7b77a]/40 bg-[#242633] px-7 text-center"><Check size={25} className="text-[#d7b77a]" /><h3 className="mt-5 font-serif text-3xl">Thank you for reaching out.</h3><p className="mt-3 max-w-sm text-sm leading-6 text-[#bcb8ae]">Your enquiry has been noted. For the next step, please connect with Skyline directly using the details available to you.</p><button className="mt-7 border-b border-[#d7b77a] pb-2 text-[11px] uppercase tracking-[.16em] text-[#d7b77a]" onClick={() => setSubmitted(false)} data-testid="button-new-enquiry">Send another enquiry</button></div> : <form onSubmit={handleEnquiry} noValidate className="space-y-5"><label className="block"><span className="mb-2 block text-[11px] uppercase tracking-[.13em] text-[#aaa8a2]">Name</span><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full border-b border-[#f8f3eb]/25 bg-transparent px-0 py-3 text-base outline-none transition-colors placeholder:text-[#77777a] focus:border-[#d7b77a]" placeholder="Your name" data-testid="input-enquiry-name" />{errors.name && <span className="mt-2 block text-xs text-[#e5a4a4]" data-testid="error-enquiry-name">{errors.name}</span>}</label><label className="block"><span className="mb-2 block text-[11px] uppercase tracking-[.13em] text-[#aaa8a2]">Mobile number</span><input value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} inputMode="numeric" className="w-full border-b border-[#f8f3eb]/25 bg-transparent px-0 py-3 text-base outline-none transition-colors placeholder:text-[#77777a] focus:border-[#d7b77a]" placeholder="10-digit mobile number" data-testid="input-enquiry-mobile" />{errors.mobile && <span className="mt-2 block text-xs text-[#e5a4a4]" data-testid="error-enquiry-mobile">{errors.mobile}</span>}</label><label className="block"><span className="mb-2 block text-[11px] uppercase tracking-[.13em] text-[#aaa8a2]">What are you exploring?</span><textarea value={form.requirement} onChange={(e) => setForm({ ...form, requirement: e.target.value })} rows={3} className="w-full resize-none border-b border-[#f8f3eb]/25 bg-transparent px-0 py-3 text-base outline-none transition-colors placeholder:text-[#77777a] focus:border-[#d7b77a]" placeholder="Location, use, timeline or any first question" data-testid="input-enquiry-requirement" />{errors.requirement && <span className="mt-2 block text-xs text-[#e5a4a4]" data-testid="error-enquiry-requirement">{errors.requirement}</span>}</label><button type="submit" className="mt-4 flex w-full items-center justify-between bg-[#d7b77a] px-5 py-4 text-left text-[11px] uppercase tracking-[.18em] text-[#242633] transition-colors hover:bg-[#efd7a5]" data-testid="button-submit-enquiry"><span>Send enquiry</span><ArrowUpRight size={17} /></button></form>}</div></div></section>

        <section className="relative min-h-[430px] overflow-hidden bg-[#c6b8a5]" data-testid="section-location"><RemoteImage src="https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg?auto=compress&cs=tinysrgb&w=1800" alt="Rajasthan landscape at golden hour" className="absolute inset-0 opacity-70" /><div className="absolute inset-0 bg-[#242633]/35" /><div className="relative mx-auto flex min-h-[430px] max-w-[1440px] items-end justify-between gap-6 px-5 pb-10 text-[#f8f3eb] sm:px-8 lg:px-12"><div><p className="font-mono text-[10px] uppercase tracking-[.22em] text-[#e5c889]">Find your bearings</p><h2 className="mt-4 max-w-lg font-serif text-5xl leading-[.9] sm:text-6xl">A local view<br />changes everything.</h2></div><a href={MAPS_URL} target="_blank" rel="noreferrer" className="flex shrink-0 items-center gap-2 border border-[#f8f3eb]/50 px-4 py-3 text-[10px] uppercase tracking-[.16em] transition-colors hover:border-[#d7b77a] hover:text-[#d7b77a]" data-testid="link-location-map">Get directions <ArrowUpRight size={15} /></a></div></section>
      </main>

      <footer className="bg-[#20222d] px-5 py-12 text-[#f8f3eb] sm:px-8 lg:px-12" data-testid="footer-site"><div className="mx-auto max-w-[1440px]"><div className="grid gap-12 border-b border-[#f8f3eb]/15 pb-12 md:grid-cols-[1.3fr_.7fr_.7fr]"><div><div className="flex items-center gap-3"><span className="flex h-10 w-10 items-center justify-center border border-[#d7b77a] font-serif text-xl text-[#d7b77a]">S</span><div><p className="font-mono text-[9px] uppercase tracking-[.22em] text-[#d7b77a]">Skyline</p><p className="text-sm">Real Estate Consultancy</p></div></div><p className="mt-6 max-w-sm text-sm leading-6 text-[#aaa8a2]">A serious local property partner for Khatushyamji and the conversations that begin here.</p></div><div><p className="font-mono text-[10px] uppercase tracking-[.2em] text-[#d7b77a]">Navigate</p><div className="mt-5 grid gap-3 text-sm text-[#c9c6be]">{navItems.slice(1).map(([label, id]) => <button key={id} onClick={() => scrollToId(id)} className="w-fit transition-colors hover:text-[#d7b77a]" data-testid={`link-footer-${id}`}>{label}</button>)}</div></div><div><p className="font-mono text-[10px] uppercase tracking-[.2em] text-[#d7b77a]">Connect</p><div className="mt-5 grid gap-3 text-sm text-[#c9c6be]"><button onClick={goToContact} className="flex w-fit items-center gap-2 hover:text-[#d7b77a]" data-testid="button-footer-enquiry"><Mail size={14} /> Start an enquiry</button><a href={MAPS_URL} target="_blank" rel="noreferrer" className="flex w-fit items-center gap-2 hover:text-[#d7b77a]" data-testid="link-footer-map"><MapPin size={14} /> Visit on Maps</a></div></div></div><div className="flex flex-col justify-between gap-4 pt-6 text-[10px] uppercase tracking-[.16em] text-[#85858a] sm:flex-row"><span>© {new Date().getFullYear()} Skyline Real Estate Consultancy Khatushyamji</span><span>{BUSINESS_PHONE ? <a href={`tel:${BUSINESS_PHONE}`} className="hover:text-[#d7b77a]">{BUSINESS_PHONE}</a> : 'Enquiry-based consultation'}</span></div></div></footer>
      <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="fixed bottom-5 right-5 z-30 flex h-11 w-11 items-center justify-center border border-[#c19a58] bg-[#242633] text-[#d7b77a] shadow-lg transition-transform hover:-translate-y-1" data-testid="button-back-to-top" aria-label="Back to top"><ArrowUp size={17} /></button>

      {selectedProperty && <div className="modal-backdrop fixed inset-0 z-[70] flex items-center justify-center bg-[#1c1d26]/80 p-4 backdrop-blur-sm" onClick={() => setSelectedProperty(null)} data-testid="modal-property-backdrop"><div className="relative grid max-h-[90vh] w-full max-w-4xl overflow-auto bg-[#f7f2e9] md:grid-cols-2" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true" aria-labelledby="property-modal-title" data-testid="modal-property-detail"><button onClick={() => setSelectedProperty(null)} className="absolute right-3 top-3 z-10 flex h-9 w-9 items-center justify-center bg-[#242633] text-[#f8f3eb]" data-testid="button-close-property-modal" aria-label="Close property details"><X size={17} /></button><div className="min-h-[270px]"><RemoteImage src={selectedProperty.image} alt={selectedProperty.title} /></div><div className="p-7 sm:p-10"><p className="font-mono text-[10px] uppercase tracking-[.2em] text-[#a37c3d]">Sample / demo · {selectedProperty.category}</p><h2 id="property-modal-title" className="mt-4 font-serif text-4xl leading-none">{selectedProperty.title}</h2><p className="mt-6 text-sm leading-7 text-[#6f6c66]">{selectedProperty.description}</p><div className="mt-7 space-y-3 border-t border-[#d8d0c3] pt-5">{selectedProperty.highlights.map((highlight) => <div className="flex items-center gap-3 text-sm" key={highlight}><Check size={15} className="text-[#a37c3d]" /> {highlight}</div>)}</div><button onClick={() => { setSelectedProperty(null); goToContact(); }} className="mt-9 flex w-full items-center justify-between bg-[#242633] px-5 py-4 text-[11px] uppercase tracking-[.16em] text-[#f8f3eb] hover:bg-[#343746]" data-testid="button-modal-enquire">Enquire about your requirement <ArrowUpRight size={16} /></button></div></div></div>}
    </div>
  );
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={Home} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;